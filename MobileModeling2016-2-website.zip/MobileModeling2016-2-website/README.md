# MobileModeling2016-2

## Développeurs

Keyvan
Gilles
François

## Implémenter une nouvelle page 

Dans vues/, créer une copie de template.html
Lui donner un nom explicite sans majuscules, sans accents, sans espaces (sinon underscore), sans apostrophes
Exemple : page_1.html, page_2.html, page_3.html

Pour le visualiser, ouvrez le fichier manuellement dans le navigateur. L'implémentation de la navigation sera faite au fur et a mesure.